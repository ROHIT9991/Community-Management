package com.infosys.module4.exception;

public class PostException extends RuntimeException {
    public PostException(String message) {
        super(message);
    }
}
