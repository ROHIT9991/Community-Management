package com.infosys.module4.exception;

public class ParkingException extends RuntimeException {
    public ParkingException(String message) {
        super(message);
    }
}
