package com.infosys.module4.exception;

public class NoticeException extends RuntimeException {
    public NoticeException(String message) {
        super(message);
    }
}
