package com.infosys.module4.exception;

public class EmergencyContactException extends RuntimeException {
    public EmergencyContactException(String message) {
        super(message);
    }
}
