package com.infosys.module4.exception;

public class FeedbackException extends RuntimeException {
    public FeedbackException(String message) {
        super(message);
    }
}
