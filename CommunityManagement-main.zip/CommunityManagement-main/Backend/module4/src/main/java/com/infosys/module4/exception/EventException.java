package com.infosys.module4.exception;

public class EventException extends RuntimeException {
    public EventException(String message) {
        super(message);
    }
}
