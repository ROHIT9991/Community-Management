package com.infosys.module4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoticeboardEventsPostServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
