package com.infosys.module2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocietymanagementserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
