package com.infosys.module2.exception;

public class RegistrationException extends Exception{

    public RegistrationException(String message){
        super(message);
    }
}
