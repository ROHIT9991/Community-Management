package com.infosys.module2.config;

public class JwtConstant {
    public static String JWT_HEADER="Authorization";
    public static String SECRET_STRING="abcdefghijklmnopqrstuvwxyzabcdefghinjkl";
}
