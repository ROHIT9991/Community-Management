package com.infosys.module1.exception;

public class LoginException extends Exception{
    public LoginException(String message){
        super(message);
    }
}
