package com.infosys.module1.exception;

public class RegistrationException extends Exception{
    public RegistrationException(String message){
        super(message);
    }
}
