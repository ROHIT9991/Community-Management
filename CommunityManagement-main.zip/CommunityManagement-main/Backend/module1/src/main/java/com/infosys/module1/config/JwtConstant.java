package com.infosys.module1.config;

public class JwtConstant {
    public static String JWT_HEADER="Authorization";
    public static String SECRET_STRING="abcdefghijklmnopqrstuvwxyzabcdefghinjkl";
}
