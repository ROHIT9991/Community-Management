package com.infosys.module5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingAndPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
