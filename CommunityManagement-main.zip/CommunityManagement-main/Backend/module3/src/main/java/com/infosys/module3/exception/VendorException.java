package com.infosys.module3.exception;

public class VendorException extends RuntimeException {
    public VendorException(String message) {
        super(message);
    }
}
