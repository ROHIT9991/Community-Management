package com.infosys.module3.exception;

public class RequestException extends RuntimeException {
    public RequestException(String message) {
        super(message);
    }
}
