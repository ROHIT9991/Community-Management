package com.infosys.module3.exception;

public class ComplaintException extends RuntimeException {
    public ComplaintException(String message) {
        super(message);
    }
}
