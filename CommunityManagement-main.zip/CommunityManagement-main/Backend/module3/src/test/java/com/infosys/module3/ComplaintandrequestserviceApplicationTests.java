package com.infosys.module3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintandrequestserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
